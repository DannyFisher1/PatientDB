import pandas as pd
from cases_func import find_common_facilities

def get_info(df):
    matched = find_common_facilities(df)
    return matched











